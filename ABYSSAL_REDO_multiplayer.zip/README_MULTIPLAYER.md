# ABYSSAL REDO — paquete del juego

Este ZIP contiene únicamente los archivos del juego.

- `index.html`: juego actualizado con identificación del anfitrión y relevo cuando se desconecta.

El Worker de Cloudflare vive en otro repositorio y no forma parte de este paquete.

**Estado:** se actualiza la identidad y conexión de jugadores. La sincronización autoritativa de enemigos, daño, oleadas, botín y progresión todavía está pendiente.
